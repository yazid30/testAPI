<!-- Left Sidebar -->
	<div class="left main-sidebar">
	
		<div class="sidebar-inner leftscroll">

			<div id="sidebar-menu">
        
			<ul>

					<li class="submenu">
						<a class="active" href="<?php base_url();?>welcome"><i class="fa fa-fw fa-bars"></i><span> Dashboard </span> </a>
                    </li>

					<li class="submenu">
                        <a href="<?php base_url();?>welcome/tambah"><i class="fa fa-fw fa-area-chart"></i><span> Tambah </span> </a>
                    </li>
					

										
                    <li class="submenu">
                        <a href="#"><i class="fa fa-fw fa-tv"></i> <span> Menu Dropdown </span> <span class="menu-arrow"></span></a>
                            <ul class="list-unstyled">
                                <li><a href="">Sub Menu 1</a></li>
                                <li><a href="">Sub Menu 2</a></li>
                                <li><a href="">Sub Menu 3</a></li>
                                <li><a href="">Sub Menu 4</a></li>
                                <li><a href="">Sub Menu 5</a></li>
                                <li><a href="">Sub Menu 6</a></li>
                                <li><a href="">Sub Menu 7</a></li>
                                <li><a href="">Sub Menu 8</a></li>
                            </ul>
                    </li>
					
            </ul>

            <div class="clearfix"></div>

			</div>
        
			<div class="clearfix"></div>

		</div>

	</div>
	<!-- End Sidebar -->