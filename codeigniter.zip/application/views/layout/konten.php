<?php if(!defined('BASEPATH')) exit('No direct access allowed');

if ($isi) {
	
	$this->load->view($isi);
}