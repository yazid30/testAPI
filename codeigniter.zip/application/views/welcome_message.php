<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Surat Pengantar RT/RW</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		position:static;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}
	p.foter {
		text-align: right;
		font-size: 11px;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 10px 0 0 0;
	}

	#container {
		margin: 9px;
		border: 0px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
<body>

<div id="container">
<table align="left" border="0">
<tr>
<td><img src="C:/xampp/htdocs/codeigniter/assets/images/jkt.jpg" width="90" height="100" ></td></tr>
</table><p class="foter">LAMPIRAN XII : Model AA 04</p>

	<div id="body">
	  <p font align="center" size="+1">SURAT : PENGANTAR</p>
	<p font align="center" size="+1">Nomor:</p>
		<code>Yang bertanda tangan di bawah ini, Pengurus RT.00_ / RW.08 Blok A1 Komplek Graha Cempaka Mas Kelurahan Sumur Batu Kecamatan Kemayoran Kotamadya Jakarta Pusat, Dengan Ini Menerangkan bahwa :</code>
<table border="0" cellpadding="2" cellspacing="9">
<tr>
		<td>Nama </td>
		<td>:</td>
		<td>____________________________________________________</td>
</tr>
<tr>
		<td>Jenis Kelamain </td>
		<td>:</td>
		<td>____________________________________________________</td>
	</tr>
<tr>
		<td>Tempat Tanggal Lahir </td>
		<td>:</td>
		<td>____________________________________________________</td>
	</tr>
<tr>
		<td>Nomor KTP/KK </td>
		<td>:</td>
		<td>____________________________________________________</td>
	</tr>
<tr>
		<td>Kewarganegaraan </td>
		<td>:</td>
		<td>____________________________________________________</td>
	</tr>
<tr>
		<td>Agama </td>
		<td>:</td>
		<td>____________________________________________________</td>
	</tr>
<tr>
		<td>Pekerjaan </td>
		<td>:</td>
		<td>____________________________________________________</td>
	</tr>
<tr>
		<td valign="top">Alamat </td>
		<td valign="top">:</td>
		<td>Tower ______ Lantai _____ Nomor ______ RT.001 RW.08,<br> Komplek Graha Cempaka Mas, Kelurahan Sumur Batu</td>
	</tr>
<tr>
		<td valign="top">Keperluan </td>
		<td valign="top">:</td>
		<td>____________________________________________________<br>____________________________________________________<br>____________________________________________________<br></td>
	</tr>
	</table>
	<table border="0" cellpadding="2" cellspacing="9" >
	<tr>
	<td width="200">Nomor : ___________________</td>
	<td width="200" align="right"> Jakarta, __________________</td>
	</tr>
	<tr>
	<td valign="top">Mengetahui :<br />Pengurus Rukun Warga.08<br>Kelurahan Sumur Batu</td>
	<td valign="top" align="right">Pengurus Rt.00__Rw.08<br>Kelurahan Sumur Batu<br>Ketua,</td>
</tr>
<tr>
<td height="40" valign="bottom">_______________</td>
<td height="40" valign="bottom" align="right">_______________</td>
</tr>
</table>
			</div>
	<p class="footer">@PPRSC - GCM.com || 2017</p>
</div>
</body>
</html>