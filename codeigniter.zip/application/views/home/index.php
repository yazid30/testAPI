 <div class="content-page">
	
		<!-- Start content -->
        <div class="content">
            
			<div class="container-fluid">
					
						<div class="row">
									<div class="col-xl-12">
											<div class="breadcrumb-holder">
													<h1 class="main-title float-left">Dashboard</h1>
													<ol class="breadcrumb float-right">
														<li class="breadcrumb-item">Home</li>
														<li class="breadcrumb-item active">Dashboard</li>
													</ol>
													<div class="clearfix"></div>
											</div>
									</div>
						</div>
						<!-- end row -->

						<div class="alert alert-danger alert-dismissible fade show" role="alert">
						<h4 class="alert-heading">Info!</h4>
						<p>Apakah Anda ingin pengembangan kustom untuk mengintegrasikan tema ini dalam proyek Anda? Atau tambahkan fitur baru <a target="_blank" href="https://www.yazid-ardiansyah.com"><b>Yazid Development</b></a></p>
						<p>Atau coba versi PRO kami:<b> Simpan lebih dari 50 jam pengembangan dengan Kerangka Pro kami: Registrasi / Login / Manajemen Pengguna, CMS, Template Front-End (yang akan memuat contend ditambahkan di area admin dan disimpan dalam database MySQL), Hubungi kami, mengelola Pengaturan Situs Web dan banyak lagi, dengan harga yang luar biasa!</b></p>
						<p>Read more about all PRO features here: <a target="_blank" href="#"><b>Fitur Admin PRO</b></a></p>
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
						</div>
						
							<div class="row">
									<div class="col-xs-12 col-md-6 col-lg-6 col-xl-3">
											<div class="card-box noradius noborder bg-default">
													<i class="fa fa-file-text-o float-right text-white"></i>
													<h6 class="text-white text-uppercase m-b-20">Orders</h6>
													<h1 class="m-b-20 text-white counter">1,587</h1>
													<span class="text-white">15 New Orders</span>
											</div>
									</div>

									<div class="col-xs-12 col-md-6 col-lg-6 col-xl-3">
											<div class="card-box noradius noborder bg-warning">
													<i class="fa fa-bar-chart float-right text-white"></i>
													<h6 class="text-white text-uppercase m-b-20">Visitors</h6>
													<h1 class="m-b-20 text-white counter">250</h1>
													<span class="text-white">Bounce rate: 25%</span>
											</div>
									</div>

									<div class="col-xs-12 col-md-6 col-lg-6 col-xl-3">
											<div class="card-box noradius noborder bg-info">
													<i class="fa fa-user-o float-right text-white"></i>
													<h6 class="text-white text-uppercase m-b-20">Users</h6>
													<h1 class="m-b-20 text-white counter">120</h1>
													<span class="text-white">25 New Users</span>
											</div>
									</div>

									<div class="col-xs-12 col-md-6 col-lg-6 col-xl-3">
											<div class="card-box noradius noborder bg-danger">
													<i class="fa fa-bell-o float-right text-white"></i>
													<h6 class="text-white text-uppercase m-b-20">Alerts</h6>
													<h1 class="m-b-20 text-white counter">58</h1>
													<span class="text-white">5 New Alerts</span>
											</div>
									</div>
							</div>
							<!-- end row -->
							
							
							<div class="row">

									<div class="col-md-12">						
										<div class="card mb-3">
											<div class="card-header">
												<h3><i class="fa fa-users"></i> User details</h3>
				  								Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus non luctus metus. Vivamus fermentum ultricies orci sit amet sollicitudin.
											</div>
												
											<div class="card-body">
												
												<table id="example1" class="table table-bordered table-responsive-xl table-hover display">
													<thead>
														<tr>
															<th>No</th>
															<th>Username</th>
															<th>Email</th>
															<th>Password</th>
															<th>Tanggal</th>
															<th>Action</th>
														</tr>
													</thead>													
													<tbody>

													<?php $no = 1; $data = $this->db->query("SELECT * FROM user");
           											foreach ($data->result_array() as $list) {?>
														<tr>
															<td><?php echo $no++ ?></td>
															<td><?php echo  $list['nama'];  ?></td>
															<td><?php echo  $list['email'];  ?></td>
															<td><?php echo  $list['password']; ?></td>
															<td><?php echo  $list['tanggalLahir']; ?></td>
															<td>			
																<div class="btn-group">
							                                      <a class="btn btn-success" href="<?php echo base_url() ?>welcome/edit/<?php echo $list['npm'] ?>"><i class="icon_check_alt2"></i>Edit</a>
							                                      <a class="btn btn-danger" href="<?php echo base_url() ?>welcome/delete/<?php echo $list['npm'] ?>"><i class="icon_close_alt2"></i>Hapus</a>
							                                  </div></td>
														</tr>
														
														<?php } ?>
													</tbody>
												</table>
												
											</div>														
										</div><!-- end card-->					
									</div>

									
								
							
							
													
									</div>
									
							</div>			



            </div>
			<!-- END container-fluid -->

		</div>
		<!-- END content -->

    </div>
	<!-- END content-page -->