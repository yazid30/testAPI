 <div class="content-page">
	
		<!-- Start content -->
        <div class="content">
            
			<div class="container-fluid">
					
						<div class="row">
									<div class="col-xl-12">
											<div class="breadcrumb-holder">
													<h1 class="main-title float-left">Dashboard</h1>
													<ol class="breadcrumb float-right">
														<li class="breadcrumb-item">Home</li>
														<li class="breadcrumb-item active">Edit</li>
													</ol>
													<div class="clearfix"></div>
											</div>
									</div>
						</div>
						<!-- end row -->
							<div class="row">

									<div class="col-md-12">						
										<div class="card mb-3">
	<div class="card-header">
	<h3><i class="fa fa-edit"></i> Tambah Data</h3>

	</div>
												
		<div class="card-body">
			<form name="form1" method="post" action="<?php echo base_url(); ?>welcome/tambah" class="myform">
				<p><label for="nama">ID Anda</label>
					<input class="form-control" name="npm" type="text" id="nama" size="70" value=""  required>
				</p>
				<p><label for="nama">Nama</label>
					<input class="form-control" name="nama" type="text" id="nama" size="70" placeholder="Nama"  required>
				</p>
				<p>
					<label for="ringkasan">Email</label>
					<input class="form-control" name="email" type="text" id="Email" size="70"  required>
				</p>
				<p>
					<label for="ringkasan">Password</label>
					<input class="form-control" name="password" type="Password" id="Email" size="70" placeholder="*****" required>
				</p>
				<p>
					<label for="ringkasan">Confirm Password</label>
					<input class="form-control" name="passwordconf" type="Password" id="Email" size="70" placeholder="*****" required>
				</p>
				<p>
					<input type="submit" class="btn btn-primary" name="submit" id="submit" value="Submit">
					<input type="reset" class="btn btn-primary" name="submit2" id="submit2" value="Reset">
				</p>
			</form>
		</div>
	</div>
</div>
</div>
</div>
</div>


