 <div class="content-page">
	
		<!-- Start content -->
        <div class="content">
            
			<div class="container-fluid">
					
						<div class="row">
									<div class="col-xl-12">
											<div class="breadcrumb-holder">
													<h1 class="main-title float-left">Dashboard</h1>
													<ol class="breadcrumb float-right">
														<li class="breadcrumb-item">Home</li>
														<li class="breadcrumb-item active">Edit</li>
													</ol>
													<div class="clearfix"></div>
											</div>
									</div>
						</div>
						<!-- end row -->
							<div class="row">

									<div class="col-md-12">						
										<div class="card mb-3">
	<div class="card-header">
	<h3><i class="fa fa-edit"></i> Update Data</h3>

	</div>
												
		<div class="card-body">
			<form name="form1" method="post" action="<?php echo base_url(); ?>welcome/edit" class="myform">
				<p><label for="nama">Nama</label>
					<input class="form-control" name="nama" type="text" id="nama" size="70" value="<?php echo $detail['nama'] ?>"  required>
				</p>
				<p>
					<label for="ringkasan">Email</label>
					<input class="form-control" name="email" type="text" id="Email" size="70" value="<?php echo $detail['email'] ?>"  required>
				</p>
				<p>
					<input name="id_admin" type="hidden" id="id_admin" value="1">
					<input name="npm" type="hidden" id="npm" value="<?php echo $detail['npm'] ?>">
				</p>
				<p>
					<input type="submit" class="btn btn-primary" name="submit" id="submit" value="Submit">
					<input type="reset" class="btn btn-primary" name="submit2" id="submit2" value="Reset">
				</p>
			</form>
		</div>
	</div>
</div>
</div>
</div>
</div>


