
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login</title>

    <!-- Core CSS -->
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">

	<!-- Custom CSS -->
	<link href="<?php echo base_url(); ?>assets/css/login.css" rel="stylesheet">

    <!-- Checkboxes style -->
    <link href="<?php echo base_url(); ?>assets/css/bootstrap-checkbox.css" rel="stylesheet">
</head>

<body>

<div class="login-menu">
      <div class="container">
        <nav class="nav">
          <a class="nav-link" href="https://www.yazid-ardiansyah.com">Home</a>
          <a class="nav-link active" href="https://www.pikeadmin.com/demo-pro">Login</a>
        </nav>
      </div>
</div>

<div class="container h-100">
	<div class="row h-100 justify-content-center align-items-center">
				
						
		<div class="card">
			<h4 class="card-header">Login</h4>
            
			<div class="card-body">
			

		<div class="alert alert-info alert-dismissible fade show" role="alert">
			<h5 class="alert-heading">Data Login</h5>
			   <?php   
				   // Cetak session   
				   if($this->session->flashdata('sukses')) {   
				     echo '<p class="warning" >'.$this->session->flashdata('sukses').'</p>';   
				   }   
			   ?>   
			<p>Email: saya@yazid-ardiansyah.com<br />Password: 123456</p>
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			</button>
		</div>
            <?php echo validation_errors();  ?>        	
            <form data-toggle="validator" role="form" method="post" action="<?php echo base_url();?>login/authentication">                                
								
								<div class="row">	
									<div class="col-md-12">    
									<div class="form-group">
									<label>Login Email</label>
									<div class="input-group">
								<div class="input-group-prepend">
									<span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-open-o" aria-hidden="true"></i></span>
										</div>
									  <input type="email" class="form-control" name="email" id="Email" data-error="Input valid email" required>								  
									</div>								
									<div class="help-block with-errors text-danger"></div>
									</div>
									</div>
                                </div>
								
								<div class="row">								
									<div class="col-md-12">
									<div class="form-group">
									<label>Password</label>
									<div class="input-group">
										<div class="input-group-prepend">
										<span class="input-group-text" id="basic-addon1"><i class="fa fa-unlock" aria-hidden="true"></i></span>
										</div>
										<input type="password" id="inputPassword" data-minlength="6" name="password" class="form-control" data-error="Password to short" required />
									</div>	
									<div class="help-block with-errors text-danger"></div>
									</div>
									</div>
								</div>
								
								<div class="row">								
								<div class="checkbox checkbox-primary">
                                <input id="checkbox_remember" type="checkbox" name="remember">
                                <label for="checkbox_remember"> Remember me</label>
                                </div>    
								</div>
								
                                <div class="row">
									<div class="col-md-12">
									<input type="hidden" name="redirect" value="" />
									<input type="submit" class="btn btn-primary btn-lg btn-block" value="Login" name="submit" />
									</div>
								</div>
                        </form>

                        <div class="clear"></div> 
						
						<i class="fa fa-user fa-fw"></i> No account yet? <a href="#">Register new account</a><br />
                        <i class="fa fa-undo fa-fw"></i> Forgot password? <a href="<?php base_url()?>forgot">Reset password</a>
            
			</div>	
			
		</div>	
		
	</div>	
</div>

<footer class="footer">
	<div class="container">
    <span class="text-muted">Development By Yazid.</span>
    </div>
</footer>
	
<!-- Core Scripts -->
<script src="<?php echo base_url(); ?>assets/js/jquery-1.10.2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	
<!-- Bootstrap validator  -->
<script src="<?php echo base_url(); ?>assets/js/validator.min.js"></script>

</body>
</html>