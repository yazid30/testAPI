<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Model {

  public function getCountUser()
  {
      return $this->db->count_all_results('user', FALSE);
  }

  public function getUser($page, $size)
  {
      return $this->db->get('user', $size, $page);
  }

  public function insertUser($dataUser)
  {
      $val = array(
        'npm' => $dataUser['npm'],
        'nama' => $dataUser['nama'],
        'email' => $dataUser['email'],
        'password' =>$dataUser['password'],
        'tanggalLahir' => $dataUser['tanggalLahir']
      );
      $this->db->insert('user', $val);
  }

  public function updateUser($dataUser, $npm)
  {
    $val = array(
        'npm' => $dataUser['npm'],
        'nama' => $dataUser['nama'],
        'email' => $dataUser['email'],
        'password' =>$dataUser['password'],
        'tanggalLahir' => $dataUser['tanggalLahir']
    );
    $this->db->where('npm', $npm);
    $this->db->update('user', $val);
  }

  public function deleteUser($npm)
  {
    $val = array(
      'npm' => $npm
    );
    $this->db->delete('user', $val);
  }


  // Kode untuk menampilkan detail 
  public function detail($id = FALSE) {
    if ($id === FALSE) {
      $query = $this->db->get('user');
      return $query->result_array();
    }
    $query = $this->db->get_where('user', array('npm' => $id));
    return $query->row_array();
  }

  // Kode untuk melakukan fungsi Update
  public function edit($data) {
    $this->db->where('npm', $data['npm']);
    return $this->db->update('user', $data);
  }
  public function tambah($data) {
    return $this->db->insert('user', $data);
  }
}