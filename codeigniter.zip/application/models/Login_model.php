<?php
class Login_model extends CI_Model 
{
	protected $_table = 'admin';
	function __construct()
	{
		parent::__construct();
	}
	
	function select(){
		$query = $this->db->get('admin');
		return $query->result_array();
	}
	
	function authenticate($email, $password) 
	{
		$query = $this->db->get_where($this->_table, array('email' => $email, 'password' => $password, 'status' => 1));
		$result = $query->row_array();
		
		return $result;
	}
	
	 function add($data)
    {
        $this->db->insert($this->_table, $data);
    }
	
	function get_dash_user($adminid)
	{
		$query   = $this->db->get_where('cs_users', array('id' => $adminid));
		return $query->row_array();
	}
	
	 function update($id, $data)
    {
		$this->db->where('id', $id);
		$this->db->update($this->_table, $data); 
	}
	
	function delete($adminid)
	{
		$this->db->delete($this->_table, array('id' => $adminid)); 
	}
	
	function count_dash_user()
	{
		return $this->db->count_all('cs_users');
	}
	
	function list_dash_user($sort = array())
    {
		if(! empty($sort))
		$this->db->select('cs_users.*');
		$this->db->order_by($sort['field']);
		$query  = $this->db->get($this->_table);
		return $query->result_array();
	}
	
}

?>