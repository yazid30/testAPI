<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model('Login_model');
		 // Berfungsi untuk memanggil Login_model
	}

	// Berfungsi untuk menampilkan halaman login
	function index() { 
		$this->load->view('home/login');
		}

	// Berfungsi untuk melakukan validasi login
	function authentication(){
		$this->load->library('form_validation'); 
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if($this->form_validation->run() == FALSE)
		{
			redirect('login');
		}
		else
			{
				$email = $this->input->post('email');
				//$password = do_hash(do_hash($this->input->post('password'),'md5'));
				$password = md5($this->input->post('password'));
				
				$userlogin = $this->Login_model->authenticate($email, $password);
				$user_id = (count($userlogin) > 0) ? $userlogin['id_admin'] : 0;
					if( $user_id )
					{
						$data_session = array(
											'username' => $userlogin['username'],
											'email'=>$userlogin['email']
										);
						$login = date("Y-m-d H:i:s");
						$this->session->set_userdata($data_session);
						redirect('welcome');
					}
					else
					{
						redirect('login');
					}
			}	 	
	 }
	// Berfungsi untuk menghapus session atau logout
	function logout() {
		session_destroy();
		redirect('login');
		}	
}