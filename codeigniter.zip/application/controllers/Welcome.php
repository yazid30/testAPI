<?php if(!defined('BASEPATH')) exit('No direct access allowed');

class Welcome extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('User'); // Berfungsi untuk me-load User Model
	}

	public function index() {
		if ($this->session->userdata('username')){
 
			   
			    
		$data = array('title'=>'Yazid Ardiansyah',
		'isi'		=>'home/index'
		);
		$this->load->view('layout/wrapper', $data);
		}else
			{

			// jika tidak ada maka akan dikembalikan ke halaman login
			$this->load->view('home/login');
		} 
	}	

// Kode untuk menambah artikel  
	public function tambah() {

		$this->form_validation->set_rules('nama', 'nama', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required|matches[passwordconf]');
		$this->form_validation->set_rules('passwordconf', 'Password Confirmation', 'required');
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('npm', 'npm', 'required');

		if ($this->form_validation->run() === FALSE) {
			$data = array('title' 	=> 'Menambah Member',
							'isi'	=> 'home/tambah'
							);
			$this->load->view('layout/wrapper', $data);
		} else {
			$data = array (
				'npm'				=> $this->input->post('npm'),
				'nama' 				=> $this->input->post('nama'),
				'email'				=> $this->input->post('email'),
				'password' 			=> sha1(md5($this->input->post('password'))),
				'tanggalLahir'		=> date('Y-m-d H:i:s')
				);
			$this->User->tambah($data);
			redirect(base_url().'welcome');
			}
		} // END FUNGSI TAMBAH

// Kode untuk menampilkan halaman edit dan meng-update
	public function edit($id) {
		$this->form_validation->set_rules('nama', 'Nama', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');

		if ($this->form_validation->run() === FALSE) {
			$data['edit']	= $this->User->detail();
			$data['detail']		= $this->User->detail($id);
			$data = array (
				'title' 	=> 'Update : '.$data['detail']['nama'],
				'edit'	=> $this->User->detail(),
				'detail'	=> $this->User->detail($id),
				'isi'		=> 'home/edit'
				);
			$this->load->view('layout/wrapper', $data);
			// Jika tidak terjadi error maka artikel akan diupdate
		}else{
			$data = array (
				'npm'		=> $this->input->post('npm'),
				'nama'				=> $this->input->post('nama'),
				'email'			=> $this->input->post('email')
				
				);
			$this->User->edit($data);
			redirect(base_url().'welcome');
		}		
	} // END FUNGSI MENAMPILKAN HALAMAN EDIT DAN UPDATE

  public function delete($npm) {
    $this->User->deleteUser($npm);
    redirect(base_url().'welcome');
  } // END FUNGSI DELETE
}